// 𝗖𝗢𝗡𝗧𝗥𝗢𝗟 𝗕𝗢𝗧 

global.prefa = ['','!','.',',','🐤','🗿'] //NOT CHANGE
global.owner = ['6285727819741'] //OWNER
global.botname = 'Finix 5.0.0' //BOT NAME
global.baileys1 = require('@whiskeysockets/baileys') //NOT CHANGE
global.creator = "TamaRyuichi" //NOT CHANGE
global.packname = "Sticker By" //OPSIONAL
global.author = "TamaRyuichi" //OPSIONAL
global.idCH = "120363321780343299@newsletter" // OPSIONAL